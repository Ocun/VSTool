﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Digiwin.Common.UI;
using Digiwin.Common;
using Digiwin.Common.Torridity;

namespace Digiwin.ERP.XTEST.UI.Implement
{
    [EventInterceptorClass]
    sealed class SaveInterceptor : ServiceComponent
    {        
		//ADD
    }
}
