﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Digiwin.Common;
using System.ComponentModel;
using Digiwin.Common.UI;

namespace Digiwin.ERP.XTEST.UI.Implement
{
    [EventInterceptorClass]
    sealed class GuideInterceptor:ServiceComponent
    {       
        //ADD
    }
}
