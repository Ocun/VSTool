﻿using Digiwin.Common;
using Digiwin.Common.UI;

namespace Digiwin.ERP.XTEST.UI.Implement
{
    [EventInterceptorClass]
    internal sealed class _DocumentConfirmInterceptor_: ServiceComponent
    {
		//ADD
    }
}
