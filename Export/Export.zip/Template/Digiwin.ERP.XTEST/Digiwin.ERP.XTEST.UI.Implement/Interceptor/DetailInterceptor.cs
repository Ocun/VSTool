﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Digiwin.Common;
using Digiwin.Common.Services;
using Digiwin.Common.Torridity;
using Digiwin.ERP.Common.Utils;
using Digiwin.Common.UI;

namespace Digiwin.ERP.XTEST.UI.Implement
{
    [EventInterceptorClass]
    internal sealed class _DetailInterceptor_ : ServiceComponent
    {        
		//ADD
    }
}
