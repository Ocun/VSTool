﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Digiwin.Common;
using Digiwin.Common.Torridity;

namespace Digiwin.ERP.XTEST.Business
{
    [TypeKeyOnly]	
    public interface _ITestsService_
    {

    }
}
