using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Globalization;
using Digiwin.Common;
using Digiwin.Common.Core;
using Digiwin.Common.Query2;
using Digiwin.Common.Report;
using Digiwin.Common.Services;
using Digiwin.Common.Torridity;
using Digiwin.Common.Torridity.Metadata;
using Digiwin.ERP.Common.Business;
using Digiwin.ERP.CommonSupplyChain.Business;

namespace Digiwin.ERP.XTEST.Business.Implement {
    [EventInterceptorClass]
    public class UpdateDataSourceInterceptor : ServiceComponent 
	{
		//ADD
    }
}
