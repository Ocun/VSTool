﻿using System;
using System.ComponentModel;
using Digiwin.Common;
using Digiwin.Common.Query2;
using Digiwin.Common.Services;
using Digiwin.Common.Torridity;
using Digiwin.ERP.CommonSupplyChain.Business;
using System.Globalization;
using Digiwin.ERP.Common.Utils;

namespace Digiwin.ERP.XTEST.Business.Implement {
    [EventInterceptorClass]
    internal sealed class _ApproveSInterceptor_ : ServiceComponent {        
        //ADD
    }
}