﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using Digiwin.Common;
using Digiwin.Common.Query2;
using Digiwin.Common.Services;
using Digiwin.Common.Torridity;
using Digiwin.ERP.Common.Utils;
using Digiwin.ERP.Common.Business;


namespace Digiwin.ERP.XTEST.Business.Implement
{
    [EventInterceptorClass]
    internal sealed class SaveSInterceptor : ServiceComponent
    {
		//ADD
    }
}