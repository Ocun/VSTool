﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Digiwin.Common;
using Digiwin.Common.Query2;
using Digiwin.Common.Services;
using Digiwin.Common.Torridity;
using Digiwin.ERP.Common.Utils;
using Digiwin.Common.Report;


namespace Digiwin.ERP.XTEST.Business.Implement
{
    [EventInterceptorClass]
    internal sealed class DetailInterceptorS : ServiceComponent
    {       
        //ADD
    }
    
}
